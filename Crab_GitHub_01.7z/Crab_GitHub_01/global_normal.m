%unconditional - normal - global min
clear;
clc;

N = 1274;
%number of substrate
J = 4;

load('nm_s_m_j.mat');
S = nm_s_m_j(:,2);
m = nm_s_m_j(:,3);

mu = [0.349995785138666;0.532792646225787;0.222523228967794;0.874216093940454];
% mu_cl = [0.127714511346166;0.401124587630196;0.0560869578326724;0.153015769936110];
% mu_ub = [0.730827726192666;0.688295227959533;0.561894693528610;2.45097128857412];

for i=1:4
    nb(i,1) = N-(sum(m)-m(i));
end

gs = GlobalSearch;
fun = @(xf) (-1)*( ...
            S'*log(xf(1:4)) - m'*(xf(1:4) + log(1-exp(-xf(1:4))))...
            + ones(1,4)*log( ...
              normcdf(m+0.5, xf(5:8).*(1-exp(-xf(1:4))), sqrt(xf(5:8).*(1-exp(-xf(1:4))).*exp(-xf(1:4)) ) )...
            - normcdf(m-0.5, xf(5:8).*(1-exp(-xf(1:4))), sqrt(xf(5:8).*(1-exp(-xf(1:4))).*exp(-xf(1:4)) ) )...
                            ) ...
                  );

lb = [0;0;0;0;m];
ub = [5;5;5;5;nb];
Aeq = [0,0,0,0,1,1,1,1];
beq = N;

%xf0 =[mu; N.*(m/sum(m))];
xf0 = [mu;188;850;188;48];

problem = createOptimProblem('fmincon','x0',xf0,'objective',fun,'lb',lb,'ub',ub,'Aeq',Aeq,'beq',beq);
[xf,fval] = run(gs,problem);

%%
%global normal with n_3 fixed at 760
clear;
clc;

N = 1274;
%number of substrate
J = 4;

load('nm_s_m_j.mat');
S = nm_s_m_j(:,2);
m = nm_s_m_j(:,3);

mu = [0.349995785138666;0.532792646225787;0.222523228967794;0.874216093940454];
% mu_cl = [0.127714511346166;0.401124587630196;0.0560869578326724;0.153015769936110];
% mu_ub = [0.730827726192666;0.688295227959533;0.561894693528610;2.45097128857412];

for i=1:4
    nb(i,1) = N-(sum(m)-m(i));
end

n3 = 760;
gs = GlobalSearch;
fun = @(xf) (-1)*( ...
            S'*log(xf(1:4)) - m'*(xf(1:4) + log(1-exp(-xf(1:4))))...
            + ones(1,4)*log( ...
              normcdf(m+0.5, [xf(5:6);n3;xf(7)].*(1-exp(-xf(1:4))), sqrt([xf(5:6);n3;xf(7)].*(1-exp(-xf(1:4))).*exp(-xf(1:4)) ) )...
            - normcdf(m-0.5, [xf(5:6);n3;xf(7)].*(1-exp(-xf(1:4))), sqrt([xf(5:6);n3;xf(7)].*(1-exp(-xf(1:4))).*exp(-xf(1:4)) ) )...
                            ) ...
                  );

lb = [0;0;0;0;m(1);m(2);m(4)];
ub = [5;5;5;5;nb(1);nb(2);nb(4)];
Aeq = [0,0,0,0,1,1,1];
beq = N-n3;

xf0 = [mu;188;850;48];

problem = createOptimProblem('fmincon','x0',xf0,'objective',fun,'lb',lb,'ub',ub,'Aeq',Aeq,'beq',beq);
[xf,fval] = run(gs,problem);

%% make s3 = 31

clear;
clc;

N = 1274;
%number of substrate
J = 4;

load('nm_s_m_j.mat');
S = nm_s_m_j(:,2);
m = nm_s_m_j(:,3);

S(3) = 31;

mu = [0.349995785138666;0.532792646225787;0.222523228967794;0.874216093940454];
% mu_cl = [0.127714511346166;0.401124587630196;0.0560869578326724;0.153015769936110];
% mu_ub = [0.730827726192666;0.688295227959533;0.561894693528610;2.45097128857412];

for i=1:4
    nb(i,1) = N-(sum(m)-m(i));
end

gs = GlobalSearch;
fun = @(xf) (-1)*( ...
            S'*log(xf(1:4)) - m'*(xf(1:4) + log(1-exp(-xf(1:4))))...
            + ones(1,4)*log( ...
              normcdf(m+0.5, xf(5:8).*(1-exp(-xf(1:4))), sqrt(xf(5:8).*(1-exp(-xf(1:4))).*exp(-xf(1:4)) ) )...
            - normcdf(m-0.5, xf(5:8).*(1-exp(-xf(1:4))), sqrt(xf(5:8).*(1-exp(-xf(1:4))).*exp(-xf(1:4)) ) )...
                            ) ...
                  );

lb = [0;0;0;0;m];
ub = [5;5;5;5;nb];
Aeq = [0,0,0,0,1,1,1,1];
beq = N;

xf0 = [mu;188;850;188;48];

problem = createOptimProblem('fmincon','x0',xf0,'objective',fun,'lb',lb,'ub',ub,'Aeq',Aeq,'beq',beq);
[xf,fval] = run(gs,problem);

%% make s3 = 32 and m3 = 27

clear;
clc;

N = 1274;
%number of substrate
J = 4;

load('nm_s_m_j.mat');
S = nm_s_m_j(:,2);
m = nm_s_m_j(:,3);

S(3) = 32;
m(3) = 27;

mu = [0.349995785138666;0.532792646225787;0.222523228967794;0.874216093940454];
% mu_cl = [0.127714511346166;0.401124587630196;0.0560869578326724;0.153015769936110];
% mu_ub = [0.730827726192666;0.688295227959533;0.561894693528610;2.45097128857412];

for i=1:4
    nb(i,1) = N-(sum(m)-m(i));
end

gs = GlobalSearch;
fun = @(xf) (-1)*( ...
            S'*log(xf(1:4)) - m'*(xf(1:4) + log(1-exp(-xf(1:4))))...
            + ones(1,4)*log( ...
              normcdf(m+0.5, xf(5:8).*(1-exp(-xf(1:4))), sqrt(xf(5:8).*(1-exp(-xf(1:4))).*exp(-xf(1:4)) ) )...
            - normcdf(m-0.5, xf(5:8).*(1-exp(-xf(1:4))), sqrt(xf(5:8).*(1-exp(-xf(1:4))).*exp(-xf(1:4)) ) )...
                            ) ...
                  );

lb = [0;0;0;0;m];
ub = [5;5;5;5;nb];
Aeq = [0,0,0,0,1,1,1,1];
beq = N;

xf0 = [mu;188;810;188;48];

problem = createOptimProblem('fmincon','x0',xf0,'objective',fun,'lb',lb,'ub',ub,'Aeq',Aeq,'beq',beq);
[xf,fval] = run(gs,problem);

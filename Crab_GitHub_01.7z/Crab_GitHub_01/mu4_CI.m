%%
%profile log - mu_4 - with figure
clear;
clc;
N = 1274;
%number of substrate
J = 4;

load('nm_s_m_j.mat');
S = nm_s_m_j(:,2);
m = nm_s_m_j(:,3);

mu = [0.349995785138666;0.532792646225787;0.222523228967794;0.874216093940454];

for i=1:4
    nb(i,1) = N-(sum(m)-m(i));
end

out = [];
gs = GlobalSearch;
for x4 = 0.1:0.1:3
    
   fun = @(xf) (-1)*( ...
         S'*log([xf(1:3);x4]) - m'*([xf(1:3);x4] + log(1-exp(-[xf(1:3);x4])))...
         + ones(1,4)*log( ...
           normcdf(m+0.5, xf(4:7).*(1-exp(-[xf(1:3);x4])), sqrt(xf(4:7).*(1-exp(-[xf(1:3);x4])).*exp(-[xf(1:3);x4]) ) )...
         - normcdf(m-0.5, xf(4:7).*(1-exp(-[xf(1:3);x4])), sqrt(xf(4:7).*(1-exp(-[xf(1:3);x4])).*exp(-[xf(1:3);x4]) ) )...
                            ) ...
                  );

        lb = [0;0;0;m];
        ub = [5;5;5;nb];
        Aeq = [0,0,0,1,1,1,1];
        beq = N;
        xf0 = [mu(1);mu(2);mu(3);92;415;760;5.8];
        
        problem = createOptimProblem('fmincon','x0',xf0,'objective',fun,'lb',lb,'ub',ub,'Aeq',Aeq,'beq',beq);
        [x,fval] = run(gs,problem);
    
        out = [out;fval,x4,x'];
end
plot(out(:,2),out(:,1))
ylabel('log likelihood')
xlabel('mu4')
y_pro_min = min(out(:,1));
y_ci = y_pro_min + 0.5*3.841;
xline(1.0553)
yline(y_ci)
%y_ci = 111.7989

%%
%profile log - mu_4 - CI
clear;
clc;
N = 1274;
%number of substrate
J = 4;

load('nm_s_m_j.mat');
S = nm_s_m_j(:,2);
m = nm_s_m_j(:,3);

mu = [0.349995785138666;0.532792646225787;0.222523228967794;0.874216093940454];

for i=1:4
    nb(i,1) = N-(sum(m)-m(i));
end

out = [];
gs = GlobalSearch;

for x4 = 2.83:0.001:2.84
    
   fun = @(xf) (-1)*( ...
         S'*log([xf(1:3);x4]) - m'*([xf(1:3);x4] + log(1-exp(-[xf(1:3);x4])))...
         + ones(1,4)*log( ...
           normcdf(m+0.5, xf(4:7).*(1-exp(-[xf(1:3);x4])), sqrt(xf(4:7).*(1-exp(-[xf(1:3);x4])).*exp(-[xf(1:3);x4]) ) )...
         - normcdf(m-0.5, xf(4:7).*(1-exp(-[xf(1:3);x4])), sqrt(xf(4:7).*(1-exp(-[xf(1:3);x4])).*exp(-[xf(1:3);x4]) ) )...
                            ) ...
                  );

        lb = [0;0;0;m];
        ub = [5;5;5;nb];
        Aeq = [0,0,0,1,1,1,1];
        beq = N;
        xf0 = [mu(1);mu(2);mu(3);92;415;760;5.8];
        
        problem = createOptimProblem('fmincon','x0',xf0,'objective',fun,'lb',lb,'ub',ub,'Aeq',Aeq,'beq',beq);
        [x,fval] = run(gs,problem);
    
        out = [out;fval,x4,x'];
end


%profile log - mu_2 - with figure
clear;
clc;
N = 1274;
%number of substrate
J = 4;

load('nm_s_m_j.mat');
S = nm_s_m_j(:,2);
m = nm_s_m_j(:,3);

mu = [0.349995785138666;0.532792646225787;0.222523228967794;0.874216093940454];

for i=1:4
    nb(i,1) = N-(sum(m)-m(i));
end

out = [];
gs = GlobalSearch;
for x2 = 0.2:0.1:1.4
    
   fun = @(xf) (-1)*( ...
         S'*log([xf(1);x2;xf(2:3)]) - m'*([xf(1);x2;xf(2:3)] + log(1-exp(-[xf(1);x2;xf(2:3)])))...
         + ones(1,4)*log( ...
           normcdf(m+0.5, xf(4:7).*(1-exp(-[xf(1);x2;xf(2:3)])), sqrt(xf(4:7).*(1-exp(-[xf(1);x2;xf(2:3)])).*exp(-[xf(1);x2;xf(2:3)]) ) )...
         - normcdf(m-0.5, xf(4:7).*(1-exp(-[xf(1);x2;xf(2:3)])), sqrt(xf(4:7).*(1-exp(-[xf(1);x2;xf(2:3)])).*exp(-[xf(1);x2;xf(2:3)]) ) )...
                            ) ...
                  );

        lb = [0;0;0;m];
        ub = [5;5;5;nb];
        Aeq = [0,0,0,1,1,1,1];
        beq = N;
        xf0 = [mu(1);mu(3);mu(4);188;850;188;48];
        problem = createOptimProblem('fmincon','x0',xf0,'objective',fun,'lb',lb,'ub',ub,'Aeq',Aeq,'beq',beq);
        [x,fval] = run(gs,problem);
    
        out = [out;fval,x2,x'];
end
plot(out(:,2),out(:,1))
ylabel('log likelihood')
xlabel('mu2')
y_pro_min = min(out(:,1));
y_ci = y_pro_min + 0.5*3.841;
xline(0.5247)
yline(y_ci)
%y_ci = 111.8540

%%
%CI of mu_2
clear;
clc;
N = 1274;
%number of substrate
J = 4;

load('nm_s_m_j.mat');
S = nm_s_m_j(:,2);
m = nm_s_m_j(:,3);

mu = [0.349995785138666;0.532792646225787;0.222523228967794;0.874216093940454];

for i=1:4
    nb(i,1) = N-(sum(m)-m(i));
end

out = [];
gs = GlobalSearch;
for x2 = 0.68:0.001:0.69
    
   fun = @(xf) (-1)*( ...
         S'*log([xf(1);x2;xf(2:3)]) - m'*([xf(1);x2;xf(2:3)] + log(1-exp(-[xf(1);x2;xf(2:3)])))...
         + ones(1,4)*log( ...
           normcdf(m+0.5, xf(4:7).*(1-exp(-[xf(1);x2;xf(2:3)])), sqrt(xf(4:7).*(1-exp(-[xf(1);x2;xf(2:3)])).*exp(-[xf(1);x2;xf(2:3)]) ) )...
         - normcdf(m-0.5, xf(4:7).*(1-exp(-[xf(1);x2;xf(2:3)])), sqrt(xf(4:7).*(1-exp(-[xf(1);x2;xf(2:3)])).*exp(-[xf(1);x2;xf(2:3)]) ) )...
                            ) ...
                  );

        lb = [0;0;0;m];
        ub = [5;5;5;nb];
        Aeq = [0,0,0,1,1,1,1];
        beq = N;
        xf0 = [mu(1);mu(3);mu(4);188;850;188;48];
        problem = createOptimProblem('fmincon','x0',xf0,'objective',fun,'lb',lb,'ub',ub,'Aeq',Aeq,'beq',beq);
        [x,fval] = run(gs,problem);
    
        out = [out;fval,x2,x'];
end



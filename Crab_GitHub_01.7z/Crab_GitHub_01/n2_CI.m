%%
%profile log - n_2 - with figure
clear;
clc;
N = 1274;
%number of substrate
J = 4;

load('nm_s_m_j.mat');
S = nm_s_m_j(:,2);
m = nm_s_m_j(:,3);

%mu = [0.3440;0.524;0.037;1.055];
mu = [0.349995785138666;0.532792646225787;0.222523228967794;0.874216093940454];

for i=1:4
    nb(i,1) = N-(sum(m)-m(i));
end

out = [];
gs = GlobalSearch;
for n2 = 310:15:600
    
   fun = @(xf) (-1)*( ...
         S'*log(xf(1:4)) - m'*(xf(1:4) + log(1-exp(-xf(1:4))))...
         + ones(1,4)*log( ...
           normcdf(m+0.5, [xf(5);n2;xf(6:7)].*(1-exp(-xf(1:4))), sqrt([xf(5);n2;xf(6:7)].*(1-exp(-xf(1:4))).*exp(-xf(1:4) ) ) )...
         - normcdf(m-0.5, [xf(5);n2;xf(6:7)].*(1-exp(-xf(1:4))), sqrt([xf(5);n2;xf(6:7)].*(1-exp(-xf(1:4))).*exp(-xf(1:4) ) ) )...
                         ) ...
                     );

        lb = [0;0;0;0;m(1);m(3);m(4)];
        ub = [5;5;5;5;nb(1);nb(3);nb(4)];
        Aeq = [0,0,0,0,1,1,1];
        beq = N-n2;
        xf0 = [mu;188;188;48];
        
        problem = createOptimProblem('fmincon','x0',xf0,'objective',fun,'lb',lb,'ub',ub,'Aeq',Aeq,'beq',beq);
        [x,fval] = run(gs,problem);
    
        out = [out;fval,n2,x'];
end
plot(out(:,2),out(:,1))
ylabel('log likelihood')
xlabel('n2')
y_pro_min = min(out(:,1));
y_ci = y_pro_min + 0.5*3.841;
xline(415.28)
yline(y_ci)
%y_ci = 111.7968

%%
%profile log - n1 - CI
clear;
clc;
N = 1274;
%number of substrate
J = 4;

load('nm_s_m_j.mat');
S = nm_s_m_j(:,2);
m = nm_s_m_j(:,3);

%mu = [0.3440;0.524;0.037;1.055];
mu = [0.349995785138666;0.532792646225787;0.222523228967794;0.874216093940454];

for i=1:4
    nb(i,1) = N-(sum(m)-m(i));
end

out = [];
gs = GlobalSearch;
for n2 = 325:1:335
    
   fun = @(xf) (-1)*( ...
         S'*log(xf(1:4)) - m'*(xf(1:4) + log(1-exp(-xf(1:4))))...
         + ones(1,4)*log( ...
           normcdf(m+0.5, [xf(5);n2;xf(6:7)].*(1-exp(-xf(1:4))), sqrt([xf(5);n2;xf(6:7)].*(1-exp(-xf(1:4))).*exp(-xf(1:4) ) ) )...
         - normcdf(m-0.5, [xf(5);n2;xf(6:7)].*(1-exp(-xf(1:4))), sqrt([xf(5);n2;xf(6:7)].*(1-exp(-xf(1:4))).*exp(-xf(1:4) ) ) )...
                         ) ...
                     );

        lb = [0;0;0;0;m(1);m(3);m(4)];
        ub = [5;5;5;5;nb(1);nb(3);nb(4)];
        Aeq = [0,0,0,0,1,1,1];
        beq = N-n2;
        xf0 = [mu;188;188;48];
        
        problem = createOptimProblem('fmincon','x0',xf0,'objective',fun,'lb',lb,'ub',ub,'Aeq',Aeq,'beq',beq);
        [x,fval] = run(gs,problem);
    
        out = [out;fval,n2,x'];
end


%%
%profile log - mu_3 - with figure
clear;
clc;
N = 1274;
%number of substrate
J = 4;

load('nm_s_m_j.mat');
S = nm_s_m_j(:,2);
m = nm_s_m_j(:,3);

mu = [0.349995785138666;0.532792646225787;0.222523228967794;0.874216093940454];

for i=1:4
    nb(i,1) = N-(sum(m)-m(i));
end

out = [];
gs = GlobalSearch;
for x3 = 0.01:0.01:0.1
    
   fun = @(xf) (-1)*( ...
         S'*log([xf(1);xf(2);x3;xf(3)]) - m'*([xf(1);xf(2);x3;xf(3)] + log(1-exp(-[xf(1);xf(2);x3;xf(3)])))...
         + ones(1,4)*log( ...
           normcdf(m+0.5, xf(4:7).*(1-exp(-[xf(1);xf(2);x3;xf(3)])), sqrt(xf(4:7).*(1-exp(-[xf(1);xf(2);x3;xf(3)])).*exp(-[xf(1);xf(2);x3;xf(3)]) ) )...
         - normcdf(m-0.5, xf(4:7).*(1-exp(-[xf(1);xf(2);x3;xf(3)])), sqrt(xf(4:7).*(1-exp(-[xf(1);xf(2);x3;xf(3)])).*exp(-[xf(1);xf(2);x3;xf(3)]) ) )...
                            ) ...
                  );

        lb = [0;0;0;m];
        ub = [5;5;5;nb];
        Aeq = [0,0,0,1,1,1,1];
        beq = N;
        xf0 = [0.34;0.52;1.05;92;415;760;5.8];
        
        problem = createOptimProblem('fmincon','x0',xf0,'objective',fun,'lb',lb,'ub',ub,'Aeq',Aeq,'beq',beq);
        [x,fval] = run(gs,problem);
    
        out = [out;fval,x3,x'];
end
plot(out(:,2),out(:,1))
ylabel('log likelihood')
xlabel('mu3')
y_pro_min = min(out(:,1));
y_ci = y_pro_min + 0.5*3.841;
xline(0.0376)
yline(y_ci)
%y_ci = 111.8386

%%
%profile log - mu_3 - CI
clear;
clc;
N = 1274;
%number of substrate
J = 4;

load('nm_s_m_j.mat');
S = nm_s_m_j(:,2);
m = nm_s_m_j(:,3);

for i=1:4
    nb(i,1) = N-(sum(m)-m(i));
end

out = [];
gs = GlobalSearch;

%x3 = 0.02:0.001:0.03 low
%x3 = 0.05:0.001:0.06
for x3 = 0.05:0.001:0.06
    
   fun = @(xf) (-1)*( ...
         S'*log([xf(1);xf(2);x3;xf(3)]) - m'*([xf(1);xf(2);x3;xf(3)] + log(1-exp(-[xf(1);xf(2);x3;xf(3)])))...
         + ones(1,4)*log( ...
           normcdf(m+0.5, xf(4:7).*(1-exp(-[xf(1);xf(2);x3;xf(3)])), sqrt(xf(4:7).*(1-exp(-[xf(1);xf(2);x3;xf(3)])).*exp(-[xf(1);xf(2);x3;xf(3)]) ) )...
         - normcdf(m-0.5, xf(4:7).*(1-exp(-[xf(1);xf(2);x3;xf(3)])), sqrt(xf(4:7).*(1-exp(-[xf(1);xf(2);x3;xf(3)])).*exp(-[xf(1);xf(2);x3;xf(3)]) ) )...
                            ) ...
                  );

        lb = [0;0;0;m];
        ub = [5;5;5;nb];
        Aeq = [0,0,0,1,1,1,1];
        beq = N;
        xf0 = [0.34;0.52;1.05;92;415;760;5.8];
        
        problem = createOptimProblem('fmincon','x0',xf0,'objective',fun,'lb',lb,'ub',ub,'Aeq',Aeq,'beq',beq);
        [x,fval] = run(gs,problem);
    
        out = [out;fval,x3,x'];
end


%%
%profile log - mu_1 - with figure
clear;
clc;
N = 1274;
%number of substrate
J = 4;

load('nm_s_m_j.mat');
S = nm_s_m_j(:,2);
m = nm_s_m_j(:,3);

mu = [0.349995785138666;0.532792646225787;0.222523228967794;0.874216093940454];

for i=1:4
    nb(i,1) = N-(sum(m)-m(i));
end

out = [];
gs = GlobalSearch;
for x1 = 0.1:0.01:0.3
    
        fun = @(xf) (-1)*( ...
            S'*log([x1;xf(1:3)]) - m'*([x1;xf(1:3)] + log(1-exp(-[x1;xf(1:3)])))...
            + ones(1,4)*log( ...
              normcdf(m+0.5, xf(4:7).*(1-exp(-[x1;xf(1:3)])), sqrt(xf(4:7).*(1-exp(-[x1;xf(1:3)])).*exp(-[x1;xf(1:3)]) ) )...
            - normcdf(m-0.5, xf(4:7).*(1-exp(-[x1;xf(1:3)])), sqrt(xf(4:7).*(1-exp(-[x1;xf(1:3)])).*exp(-[x1;xf(1:3)]) ) )...
                            ) ...
                  );

        lb = [0;0;0;m];
        ub = [5;5;5;nb];
        Aeq = [0,0,0,1,1,1,1];
        beq = N;
        xf0 = [mu(2:4);188;850;188;48];
        problem = createOptimProblem('fmincon','x0',xf0,'objective',fun,'lb',lb,'ub',ub,'Aeq',Aeq,'beq',beq);
        [x,fval] = run(gs,problem);
    
        out = [out;fval,x1,x'];
end
plot(out(:,2),out(:,1))
ylabel('log likelihood')
xlabel('mu1')
y_pro_min = min(out(:,1));
y_ci = y_pro_min + 0.5*3.841;
xline(0.3440)
yline(y_ci)

%%
%small steps to find CI of mu_one
clear;
clc;
N = 1274;
%number of substrate
J = 4;

load('nm_s_m_j.mat');
S = nm_s_m_j(:,2);
m = nm_s_m_j(:,3);

mu = [0.349995785138666;0.532792646225787;0.222523228967794;0.874216093940454];

for i=1:4
    nb(i,1) = N-(sum(m)-m(i));
end

out = [];
gs = GlobalSearch;
for x1 = 0.74:0.001:0.75
    
        fun = @(xf) (-1)*( ...
            S'*log([x1;xf(1:3)]) - m'*([x1;xf(1:3)] + log(1-exp(-[x1;xf(1:3)])))...
            + ones(1,4)*log( ...
              normcdf(m+0.5, xf(4:7).*(1-exp(-[x1;xf(1:3)])), sqrt(xf(4:7).*(1-exp(-[x1;xf(1:3)])).*exp(-[x1;xf(1:3)]) ) )...
            - normcdf(m-0.5, xf(4:7).*(1-exp(-[x1;xf(1:3)])), sqrt(xf(4:7).*(1-exp(-[x1;xf(1:3)])).*exp(-[x1;xf(1:3)]) ) )...
                            ) ...
                  );

        lb = [0;0;0;m];
        ub = [5;5;5;nb];
        Aeq = [0,0,0,1,1,1,1];
        beq = N;
        xf0 = [mu(2:4);188;850;188;48];
        problem = createOptimProblem('fmincon','x0',xf0,'objective',fun,'lb',lb,'ub',ub,'Aeq',Aeq,'beq',beq);
        [x,fval] = run(gs,problem);
    
        out = [out;fval,x1,x'];
end